from detectors.pons import PonsDetector

def build_detectors():
    # Only current, verified detector data is enabled by default.
    # Add Robinfun / Virtuals / Noxa / Flap / Uniswap after their current
    # factory addresses and event ABIs are verified.
    return [PonsDetector()]
