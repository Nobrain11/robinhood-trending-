# Robinhood Chain Telegram Launch Bot

First working Python launch monitor for Robinhood Chain (chain ID 4663).

It:
- polls Robinhood Chain RPC for new blocks/logs
- detects pons launches using the current pons TokenLaunched event
- stores launches in SQLite for deduplication
- reads token metadata on-chain
- posts launch alerts to Telegram
- provides a detector framework for Robinfun, Virtuals, Noxa, Flap, Uniswap and future launchpads

## Verified current implementation

The included pons detector uses the active pons factory:

`0xA5aAb3F0c6EeadF30Ef1D3Eb997108E976351feB`

and its TokenLaunched topic:

`0xdb51ea9ad51ab453a65a4cb7e60c3cb378c9501bb002609f8f97778fb6c4235a`

Default pons start block: `8991118`.

Robinhood Chain:
- chain ID: 4663
- public RPC: https://rpc.mainnet.chain.robinhood.com
- explorer: https://robinhoodchain.blockscout.com

## Install

Python 3.11+ recommended.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Telegram

1. Message BotFather in Telegram.
2. Create a bot with `/newbot`.
3. Copy the bot token.
4. Add the bot as an administrator of your channel.
5. Set `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` in `.env`.

## Configure

Copy `.env.example` to `.env`.

For backfill:

```env
START_BLOCK=8991118
POLL_SECONDS=2
BLOCK_CHUNK=100
```

To only watch new launches, set START_BLOCK to a recent block.

## Run

```bash
python -m app
```

The database is created at `data/launches.db`.

## Architecture

```text
Robinhood Chain RPC
       |
       v
Block Poller
       |
       v
Detector Registry
 |       |       |
pons   robinfun  ...
       |
       v
SQLite dedupe/state
       |
       v
Token metadata
       |
       v
Telegram publisher
```

## Adding launchpads

Create a detector under `detectors/` implementing the same interface as `PonsDetector`.

Do not guess factory addresses or event signatures. Add them only after verifying current contracts/docs. Unknown launchpad schemas are intentionally not enabled by default.

This is an alert/indexing bot. It does not hold a private key or execute trades.
